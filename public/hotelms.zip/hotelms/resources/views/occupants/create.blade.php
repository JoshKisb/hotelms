@extends('admin.layouts.admin')

@section('title', __('occupants.create.title'))

@section('content')
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
             <form action="{{ route('occupants.store') }}" method="post" class='form-horizontal form-label-left'>
                {{ csrf_field() }}
                
                <div class="x_panel">

                    <div class="x_title">
                        <h2>{{ __('occupants.create.occupant_details') }}</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">   

                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                                {{ __('occupants.create.name') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <select id="customer" class="form-control @if($errors->has('customer')) parsley-error @endif"
                                       name="customer" required>
                                    @foreach($customers as $customer)
                                    <option value="{{ $customer->id }}">{{ title_case($customer->firstname." ".$customer->lastname) }}</option>
                                    @endforeach
                                </select>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>

                        <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="room" >
                                {{ __('occupants.create.room') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <select id="name" class="form-control @if($errors->has('room')) parsley-error @endif"
                                       name="room" required>
                                    @foreach($rooms as $room)
                                    <option value="{{ $room->id }}">{{ $room->name }}</option>
                                    @endforeach
                                </select>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>
                        
                        
                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="date" >
                                {{ __('occupants.create.date') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('date')) parsley-error @endif"
                                       name="date" value="{{  old('date') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>


                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="duration" >
                                {{ __('occupants.create.duration') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('duration')) parsley-error @endif"
                                       name="duration" value="{{  old('duration') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>                

                       
                        

                       

                        <div class="col-sm-9 col-xs-12 form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="notes">
                                {{ __('occupants.create.notes') }}
                            </label>
                            <div class="col-sm-10 col-xs-12">
                                <textarea id="notes" class="form-control @if($errors->has('notes')) parsley-error @endif"
                                    name="notes">{{ old('notes') }}</textarea>
                            </div>
                        </div>
                        
                        </div>
                    </div>
                </div>

             
                    <div class="x_panel">

                        <div class="x_title">
                            <h2>Payment Details</h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                        <div class="row">
                             <div class="col-sm-6 col-xs-12 form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="payment_method" >
                                    {{ __('occupants.create.payment_method') }}
                                </label>
                                <div class="col-sm-9 col-xs-12">
                                    <select id="payment_method" class="form-control @if($errors->has('payment_method')) parsley-error @endif"
                                           name="payment_method">
                                        <option value="cash">Cash</option>
                                    </select> 
                                    {{-- @if($errors->has('name'))
                                        <ul class="parsley-errors-list filled">
                                            @foreach($errors->get('name') as $error)
                                                    <li class="parsley-required">{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    @endif --}}
                                </div>
                            </div>    

                            <div class="col-sm-6 col-xs-12 form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="amount" >
                                    {{ __('occupants.create.amount') }}
                                </label>
                                <div class="col-sm-9 col-xs-12">
                                    <input id="amount" type="text" class="form-control @if($errors->has('amount')) parsley-error @endif"
                                           name="amount" value="{{  old('amount') }}" required>
                                    {{-- @if($errors->has('name'))
                                        <ul class="parsley-errors-list filled">
                                            @foreach($errors->get('name') as $error)
                                                    <li class="parsley-required">{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    @endif --}}
                                </div>
                            </div>  

                            <div class="clearfix"></div>

                            <div class="col-sm-6 col-xs-12 form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="total" >
                                    {{ __('occupants.create.total') }}
                                </label>
                                <div class="col-sm-9 col-xs-12">
                                    <input id="total" type="text" class="form-control @if($errors->has('total')) parsley-error @endif"
                                           name="total" value="{{  old('total') }}" disabled>
                                    {{-- @if($errors->has('name'))
                                        <ul class="parsley-errors-list filled">
                                            @foreach($errors->get('name') as $error)
                                                    <li class="parsley-required">{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    @endif --}}
                                </div>
                            </div>  

                            <div class="col-sm-6 col-xs-12 form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="balance" >
                                    {{ __('occupants.create.balance') }}
                                </label>
                                <div class="col-sm-9 col-xs-12">
                                    <input id="balance" type="text" class="form-control @if($errors->has('balance')) parsley-error @endif"
                                           name="balance" value="{{  old('balance') }}" disabled>
                                    {{-- @if($errors->has('name'))
                                        <ul class="parsley-errors-list filled">
                                            @foreach($errors->get('name') as $error)
                                                    <li class="parsley-required">{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    @endif --}}
                                </div>
                            </div>  

                        </div>
                    </div>

                </div> <!-- x_panel -->
             

                




                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="{{ URL::previous() }}"> {{ __('occupants.create.cancel') }}</a>
                        <button type="submit" class="btn btn-success"> {{ __('occupants.create.save') }}</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/admin/css/users/edit.css') }}">
@endsection

@section('scripts')
    @parent
    <script src="{{ asset('assets/admin/js/users/edit.js') }}" >
@endsection