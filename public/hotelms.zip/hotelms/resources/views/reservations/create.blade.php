@extends('admin.layouts.admin')

@section('title', __('reservations.create.title'))

@section('content')
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
             <form action="{{ route('reservations.store') }}" method="post" class='form-horizontal form-label-left'>
                {{ csrf_field() }}

                <div class="x_panel">

                    <div class="x_title">
                        <h2>{{ __('reservations.create.reservation_details') }}</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">   


                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                                {{ __('reservations.create.name') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <select id="customer" class="form-control @if($errors->has('customer')) parsley-error @endif"
                                       name="customer" required>
                                    @foreach($customers as $customer)
                                    <option value="{{ $customer->id }}">{{ title_case($customer->firstname." ".$customer->lastname) }}</option>
                                    @endforeach
                                </select>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>

                        <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="room" >
                                {{ __('reservations.create.room') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <select id="name" class="form-control @if($errors->has('room')) parsley-error @endif"
                                       name="room" required>
                                    @foreach($rooms as $room)
                                    <option value="{{ $room->id }}">{{ $room->name }}</option>
                                    @endforeach
                                </select>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>
                        
                        
                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="date" >
                                {{ __('reservations.create.date') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('date')) parsley-error @endif"
                                       name="date" value="{{  old('date') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>


                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="duration" >
                                {{ __('reservations.create.duration') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('duration')) parsley-error @endif"
                                       name="duration" value="{{  old('duration') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>                

                       
                        

                       

                        <div class="col-sm-9 col-xs-12 form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="notes">
                                {{ __('reservations.create.notes') }}
                            </label>
                            <div class="col-sm-10 col-xs-12">
                                <textarea id="notes" class="form-control @if($errors->has('notes')) parsley-error @endif"
                                    name="notes">{{ old('notes') }}</textarea>
                            </div>
                        </div>

                        
                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="{{ URL::previous() }}"> {{ __('reservations.create.cancel') }}</a>
                        <button type="submit" class="btn btn-success"> {{ __('reservations.create.save') }}</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/admin/css/users/edit.css') }}">
@endsection

@section('scripts')
    @parent
    <script src="{{ asset('assets/admin/js/users/edit.js') }}" >
@endsection