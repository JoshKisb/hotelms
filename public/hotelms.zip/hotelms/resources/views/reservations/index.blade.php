@extends('admin.layouts.admin')

@section('title', __('reservations.index.title'))

@section('content')

    <a href="{{ route('reservations.create') }}" class="btn btn-primary pull-right" style="margin: 5px 20px 15px;">
        <i class="fa fa-plus"></i>
        {{ __('reservations.index.create') }}
    </a>

    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th> {{ __('reservations.index.table_header_0') }} </th>
                <th> {{ __('reservations.index.table_header_customer') }} </th>
                <th>{{ __('reservations.index.table_header_room') }}</th>
                <th> {{ __('reservations.index.table_header_date') }} </th>
                <th> {{ __('reservations.index.table_header_duration') }} </th>
                
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            @foreach($reservations as $reservation)
                <tr>
                    <td>{{ $reservation->id }}</td>
                    <td>{{ title_case($reservation->customer->firstname." ".$reservation->customer->lastname) }}</td>
                    
                    <td>{{ $reservation->room->name }}</td>
                    <td>{{ $reservation->arrival_date }}</td>
                    <td>{{ $reservation->duration }} days</td>

                  
                    <td>
                        <a class="btn btn-xs btn-primary" href="{{ route('reservations.show', [$reservation->id]) }}" data-toggle="tooltip" data-placement="top" data-title="{{ __('reservations.index.show') }}">
                            <i class="fa fa-eye"></i>
                        </a>
                        <a class="btn btn-xs btn-info" href="{{ route('reservations.edit', [$reservation->id]) }}" data-toggle="tooltip" data-placement="top" data-title="{{ __('reservations.index.edit') }}">
                            <i class="fa fa-pencil"></i>
                        </a>
                        @can('delete', $reservation)
                        <form style="display: inline;" action="{{ route('reservations.destroy', [$reservation->id]) }}" method="POST">
                        {{ csrf_field() }}
                        {{ method_field('DELETE') }}
                            <button type="submit" class="btn btn-xs btn-danger"
                                    data-toggle="tooltip" data-placement="top" data-title="{{ __('reservations.index.delete') }}">
                                <i class="fa fa-trash"></i>
                             </button>
                        @endcan
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pull-right">
            {{-- {{ $reservations->links() }} --}}
        </div>
    </div>
@endsection