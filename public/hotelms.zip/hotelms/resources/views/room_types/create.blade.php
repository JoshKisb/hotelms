@extends('admin.layouts.admin')

@section('title', __('room_types.create.title'))

@section('content')
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
             <form action="{{ route('room_types.store') }}" method="post" class='form-horizontal form-label-left'>
                {{ csrf_field() }}

                <div class="x_panel">

                    <div class="x_title">
                        <h2>{{ __('room_types.create.roomtype_details') }}</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">

                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                                {{ __('room_types.create.name') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('fname')) parsley-error @endif"
                                       name="name" value="{{  old('name') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>

                        <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="slug" >
                                {{ __('room_types.create.slug') }}
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('slug')) parsley-error @endif"
                                       name="slug" value="{{  old('slug') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>
                        
                        

                       
                        

                       

                        <div class="col-sm-9 col-xs-12 form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pass">
                                {{ __('room_types.create.description') }}
                            </label>
                            <div class="col-sm-10 col-xs-12">
                                <textarea id="description" class="form-control @if($errors->has('description')) parsley-error @endif"
                                    name="description">{{ old('description') }}</textarea>
                            </div>
                        </div>


                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price" >
                                {{ __('room_types.create.price') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="text" class="form-control @if($errors->has('price')) parsley-error @endif"
                                       name="price" value="{{  old('price') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>

                         <div class="col-sm-6 col-xs-12 form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="room_count" >
                                {{ __('room_types.create.room_count') }}
                            </label>
                            <div class="col-sm-9 col-xs-12">
                                <input id="name" type="number" min="0" class="form-control @if($errors->has('room_count')) parsley-error @endif"
                                       name="room_count" value="{{  old('room_count') }}" required>
                                {{-- @if($errors->has('name'))
                                    <ul class="parsley-errors-list filled">
                                        @foreach($errors->get('name') as $error)
                                                <li class="parsley-required">{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif --}}
                            </div>
                        </div>
                        
                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="{{ URL::previous() }}"> {{ __('room_types.create.cancel') }}</a>
                        <button type="submit" class="btn btn-success"> {{ __('room_types.create.save') }}</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/admin/css/users/edit.css') }}">
@endsection

@section('scripts')
    @parent
    <script src="{{ asset('assets/admin/js/users/edit.js') }}" >
@endsection