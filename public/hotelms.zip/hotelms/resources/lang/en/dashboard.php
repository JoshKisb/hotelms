<?php

return [

	"title" => "Dashboard",
	"table_header_0" => "ID",
	"table_header_customer" => "Customer",
	"table_header_room" => "Room",
	"table_header_date" => "Checkout Date",
	"table_header_duration" => "Duration",

	"table_header_arrival" => "Arrival Date",

	"checkin" => "Check In",
	"checkout" => "Check Out",

	"table_price" => "Price",
	"table_status" => "Status",
	"table_header_6" => "Created",
	"show" => "View",
	"edit" => "Edit",
	"delete" => "Delete",


];
