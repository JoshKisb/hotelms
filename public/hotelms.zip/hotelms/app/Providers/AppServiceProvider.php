<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Settings;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        \Schema::defaultStringLength(191);
        $app_name_setting = Settings::where('key', 'app_name')->first();
        $app_name = isset($app_name_setting) ? $app_name_setting->value : null;

        if (is_null($app_name)) $app_name = "Hotel MS";
        view()->share('app_name', $app_name);
        view()->share('menu', '');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
