<?php $__env->startSection('title', __('customers.edit.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
             <form action="<?php echo e(route('customers.update', [$customer->id])); ?>" method="post" class='form-horizontal form-label-left'>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                        <?php echo e(__('customers.edit.fname')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="name" type="text" class="form-control <?php if($errors->has('fname')): ?> parsley-error <?php endif; ?>"
                               name="firstname" value="<?php echo e($customer->firstname); ?>" required>
                        
                    </div>
                </div>

                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                        <?php echo e(__('customers.edit.lname')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="name" type="text" class="form-control <?php if($errors->has('name')): ?> parsley-error <?php endif; ?>"
                               name="lastname" value="<?php echo e($customer->lastname); ?>" required>
                        
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">
                        <?php echo e(__('customers.edit.phone')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="phone" type="text" class="form-control <?php if($errors->has('phone')): ?> parsley-error <?php endif; ?>"
                               name="phone" value="<?php echo e($customer->phone); ?>" required>
                        
                    </div>
                </div>

                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">
                        <?php echo e(__('customers.edit.email')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="email" type="email" class="form-control <?php if($errors->has('email')): ?> parsley-error <?php endif; ?>"
                               name="email" value="<?php echo e($customer->email); ?>" required>
                        
                    </div>
                </div>

                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="gender">
                        <?php echo e(__('customers.edit.gender')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <select name="gender" id="gender" class="form-control">
                            <option value=""></option>
                            <option value="male" <?php echo e(($customer->gender == "male")?"selected":""); ?>>Male</option>
                            <option value="female" <?php echo e(($customer->gender == "female")?"selected":""); ?>>Female</option>
                        </select>
                        
                    </div>
                </div>

                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="dob">
                        <?php echo e(__('customers.edit.dob')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="dob" type="text" class="form-control <?php if($errors->has('dob')): ?> parsley-error <?php endif; ?>"
                               name="dob" value="<?php echo e($customer->dob); ?>" >
                        
                    </div>
                </div>

                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="city">
                        <?php echo e(__('customers.edit.city')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="city" type="text" class="form-control <?php if($errors->has('city')): ?> parsley-error <?php endif; ?>"
                               name="city" value="<?php echo e($customer->city); ?>" >
                        
                    </div>
                </div>

                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">
                        <?php echo e(__('customers.edit.address')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="address" type="text" class="form-control <?php if($errors->has('address')): ?> parsley-error <?php endif; ?>"
                               name="address" value="<?php echo e($customer->address); ?>">
                        
                    </div>
                </div>

                

               


                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>"> <?php echo e(__('customers.edit.cancel')); ?></a>
                        <button type="submit" class="btn btn-success"> <?php echo e(__('customers.edit.save')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/customers/edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('assets/admin/js/customers/edit.js')); ?>" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>