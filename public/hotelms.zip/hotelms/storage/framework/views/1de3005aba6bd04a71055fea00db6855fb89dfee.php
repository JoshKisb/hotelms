<?php $__env->startSection('title', __('customers.index.title')); ?>

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary pull-right" style="margin: 5px 20px 15px;">
        <i class="fa fa-plus"></i>
        <?php echo e(__('customers.index.create')); ?>

    </a>

    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th> <?php echo e(__('customers.index.table_header_0')); ?> </th>
                <th> <?php echo e(__('customers.index.table_header_1')); ?> </th>
                <th><?php echo e(__('customers.index.table_header_2')); ?></th>
                <th><?php echo e(__('customers.index.table_header_phone')); ?></th>
                <th><?php echo e(__('customers.index.table_header_address')); ?></th>
                <th> <?php echo e(__('customers.index.table_header_6')); ?> </th>
              
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer->id); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e(ucfirst($customer->firstname). " " . ucfirst($customer->lastname)); ?></td>
                    <td><?php echo e($customer->phone); ?></td>
                    <td><?php echo e($customer->address); ?></td>
                    <td><?php echo e($customer->created_at); ?></td>
                  
                    <td>
                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('customers.show', [$customer->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('customers.index.show')); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('customers.edit', [$customer->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('customers.index.edit')); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $customer)): ?>
                        <form style="display: inline;" action="<?php echo e(route('customers.destroy', [$customer->id])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-xs btn-danger"
                                    data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('customers.index.delete')); ?>">
                                <i class="fa fa-trash"></i>
                             </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-right">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>