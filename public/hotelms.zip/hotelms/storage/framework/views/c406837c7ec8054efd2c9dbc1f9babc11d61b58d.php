<?php $__env->startSection('title', __('users.index.title')); ?>

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary pull-right" style="margin: 5px 20px 15px;">
        <i class="fa fa-plus"></i>
        <?php echo e(__('users.index.create')); ?>

    </a>

    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th> <?php echo e(__('users.index.table_header_0')); ?> </th>
                <th> <?php echo e(__('users.index.table_header_1')); ?> </th>
                <th><?php echo e(__('users.index.table_header_2')); ?></th>
                <th> <?php echo e(__('users.index.table_header_3')); ?> </th>
                <th> <?php echo e(__('users.index.table_header_4')); ?> </th>
                <th> <?php echo e(__('users.index.table_header_5')); ?> </th>
                <th> <?php echo e(__('users.index.table_header_6')); ?> </th>
              
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(ucfirst($user->firstname). " " . ucfirst($user->lastname)); ?></td>
                    <td><?php echo e($user->role->name); ?></td>
                    <td>             <?php if($user->active): ?>
                            <span class="label label-primary"><?php echo e(__('users.index.active')); ?></span>
                        <?php else: ?>
                            <span class="label label-danger"><?php echo e(__('users.index.inactive')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($user->confirmed): ?>
                            <span class="label label-success"><?php echo e(__('users.index.confirmed')); ?></span>
                        <?php else: ?>
                            <span class="label label-warning"><?php echo e(__('users.index.not_confirmed')); ?></span>
                        <?php endif; ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                  
                    <td>
                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('users.show', [$user->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('users.index.show')); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('users.edit', [$user->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('users.index.edit')); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                        <form style="display: inline;" action="<?php echo e(route('users.destroy', [$user->id])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-xs btn-danger"
                                    data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('users.index.delete')); ?>">
                                <i class="fa fa-trash"></i>
                             </button>
                        <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-right">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>