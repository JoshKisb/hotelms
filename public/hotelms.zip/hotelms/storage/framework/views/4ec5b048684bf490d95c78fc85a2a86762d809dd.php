<?php $__env->startSection('title', __('roles.index.title')); ?>

<?php $__env->startSection('content'); ?>
	
	<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary pull-right" style="margin: 5px 20px 15px;">
		<i class="fa fa-plus"></i>
		<?php echo e(__('roles.index.create')); ?>

	</a>
	
    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th> <?php echo e(__('roles.index.table_header_0')); ?> </th>
                <th> <?php echo e(__('roles.index.table_header_1')); ?> </th>
                <th><?php echo e(__('roles.index.table_header_2')); ?></th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($role->id); ?></td>
                    <td><?php echo e($role->name); ?></td>
                    <td><?php echo e($role->description); ?></td>
                   
                    <td>
                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('roles.show', [$role->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('roles.index.show')); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('roles.edit', [$role->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('roles.index.edit')); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                        
                            
                                    
                                
                            
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-right">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>