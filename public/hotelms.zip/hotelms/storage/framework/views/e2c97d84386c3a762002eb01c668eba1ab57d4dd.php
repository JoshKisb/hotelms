<?php $__env->startSection('title', __('occupants.index.title')); ?>

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('occupants.create')); ?>" class="btn btn-primary pull-right" style="margin: 5px 20px 15px;">
        <i class="fa fa-plus"></i>
        <?php echo e(__('occupants.index.create')); ?>

    </a>

    <div class="row">
        <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
               width="100%">
            <thead>
            <tr>
                <th> <?php echo e(__('occupants.index.table_header_0')); ?> </th>
                <th> <?php echo e(__('occupants.index.table_header_customer')); ?> </th>
                <th><?php echo e(__('occupants.index.table_header_room')); ?></th>
                <th> <?php echo e(__('occupants.index.table_header_date')); ?> </th>
                <th> <?php echo e(__('occupants.index.table_header_duration')); ?> </th>
                
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $occupants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($occupant->id); ?></td>
                    <td><?php echo e(title_case($occupant->customer->firstname." ".$occupant->customer->lastname)); ?></td>
                    
                    <td><?php echo e($occupant->room->name); ?></td>
                    <td><?php echo e($occupant->arrival_date); ?></td>
                    <td><?php echo e($occupant->duration); ?> days</td>

                  
                    <td>
                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('occupants.show', [$occupant->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('occupants.index.show')); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('occupants.edit', [$occupant->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('occupants.index.edit')); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $occupant)): ?>
                        <form style="display: inline;" action="<?php echo e(route('occupants.destroy', [$occupant->id])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-xs btn-danger"
                                    data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('occupants.index.delete')); ?>">
                                <i class="fa fa-trash"></i>
                             </button>
                        <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-right">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>