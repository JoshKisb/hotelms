<?php $__env->startSection('title', __('settings.edit.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
             <form action="<?php echo e(route('settings.update')); ?>" method="post" class='form-horizontal form-label-left'>
                <?php echo e(csrf_field()); ?>


                <div class="col-md-12 col-xs-12">
                    <div class="x_panel">

                        <div class="x_title">
                            <h2><?php echo e(__('settings.edit.hotel_details')); ?></h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                		<div class="row">	

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_name" >
							        <?php echo e(__('settings.edit.hotel_name')); ?>

							    </label>
							    <div class="col-md-8 col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_name" type="text" class="form-control <?php if($errors->has('hotel_name')): ?> parsley-error <?php endif; ?>"
							               name="hotel_name" value="<?php echo e(isset($settings->hotel_name) ? $settings->hotel_name : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_website" >
							        <?php echo e(__('settings.edit.hotel_website')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_website" type="text" class="form-control <?php if($errors->has('hotel_website')): ?> parsley-error <?php endif; ?>"
							               name="hotel_website" value="<?php echo e(isset($settings->hotel_website) ? $settings->hotel_website : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_email" >
							        <?php echo e(__('settings.edit.hotel_email')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_email" type="text" class="form-control <?php if($errors->has('hotel_email')): ?> parsley-error <?php endif; ?>"
							               name="hotel_email" value="<?php echo e(isset($settings->hotel_email) ? $settings->hotel_email : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_phone" >
							        <?php echo e(__('settings.edit.hotel_phone')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_phone" type="text" class="form-control <?php if($errors->has('hotel_phone')): ?> parsley-error <?php endif; ?>"
							               name="hotel_phone" value="<?php echo e(isset($settings->hotel_phone) ? $settings->hotel_phone : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_country" >
							        <?php echo e(__('settings.edit.hotel_country')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_country" type="text" class="form-control <?php if($errors->has('hotel_country')): ?> parsley-error <?php endif; ?>"
							               name="hotel_country" value="<?php echo e(isset($settings->hotel_country) ? $settings->hotel_country : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_city" >
							        <?php echo e(__('settings.edit.hotel_city')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_city" type="text" class="form-control <?php if($errors->has('hotel_city')): ?> parsley-error <?php endif; ?>"
							               name="hotel_city" value="<?php echo e(isset($settings->hotel_city) ? $settings->hotel_city : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="hotel_address" >
							        <?php echo e(__('settings.edit.hotel_address')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="hotel_address" type="text" class="form-control <?php if($errors->has('hotel_address')): ?> parsley-error <?php endif; ?>"
							               name="hotel_address" value="<?php echo e(isset($settings->hotel_address) ? $settings->hotel_address : ''); ?>">
							        
							    </div>
							</div>



						</div>
                        </div>
                    </div> <!-- x_panel -->


					<div class="x_panel">

                        <div class="x_title">
                            <h2><?php echo e(__('settings.edit.app_details')); ?></h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                		<div class="row">	

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="app_name" >
							        <?php echo e(__('settings.edit.app_name')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="app_name" type="text" class="form-control <?php if($errors->has('app_name')): ?> parsley-error <?php endif; ?>"
							               name="app_name" value="<?php echo e(isset($settings->app_name) ? $settings->app_name : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="timezone" >
							        <?php echo e(__('settings.edit.timezone')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <input id="timezone" type="text" class="form-control <?php if($errors->has('timezone')): ?> parsley-error <?php endif; ?>"
							               name="timezone" value="<?php echo e(isset($settings->timezone) ? $settings->timezone : ''); ?>">
							        
							    </div>
							</div>

							<div class="col-sm-6 col-xs-12 form-group">
							    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="language" >
							        <?php echo e(__('settings.edit.language')); ?>

							        
							    </label>
							    <div class="col-md-8 col-sm-9 col-xs-12">
							        <select id="language" class="form-control <?php if($errors->has('language')): ?> parsley-error <?php endif; ?>"
							               name="language">
							               <option value="eng" <?php echo e((isset($settings->language) && $settings->language == "eng") ? "selected":""); ?>>English</option>
							        </select>
							        
							    </div>
							</div>
							


						</div>
                        </div>
                    </div> <!-- x_panel -->

                </div> <!-- col -->




				<br>
                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>"> <?php echo e(__('settings.edit.cancel')); ?></a>
                        <button type="submit" class="btn btn-success"> <?php echo e(__('settings.edit.save')); ?></button>
                    </div>
                </div>
            </form>
            <br><br>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/users/edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('assets/admin/js/users/edit.js')); ?>" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>