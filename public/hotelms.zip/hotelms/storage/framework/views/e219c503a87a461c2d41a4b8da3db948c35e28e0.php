<?php $__env->startSection('title', __('rooms.create.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
             <form action="<?php echo e(route('rooms.store')); ?>" method="post" class='form-horizontal form-label-left'>
                <?php echo e(csrf_field()); ?>


                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="room_type">
                        <?php echo e(__('rooms.create.room_type')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <select id="room_type" name="room_type" class="form-control select2" autocomplete="off">
                            <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($roomType->id); ?>"><?php echo e($roomType->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                        <?php echo e(__('rooms.create.name')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="name" type="text" class="form-control <?php if($errors->has('name')): ?> parsley-error <?php endif; ?>"
                               name="name" value="<?php echo e(old('name')); ?>" required>
                        
                    </div>
                </div>

               
                <div class="col-sm-9 col-xs-12 form-group">
                    <label class="control-label col-md-2 col-sm-2 col-xs-12" for="notes">
                        <?php echo e(__('rooms.create.notes')); ?>

                    </label>
                    <div class="col-sm-10 col-xs-12">
                        <textarea id="notes" class="form-control <?php if($errors->has('notes')): ?> parsley-error <?php endif; ?>"
                            name="notes"><?php echo e(old('notes')); ?></textarea>
                    </div>
                </div>


                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">
                        <?php echo e(__('rooms.create.status')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <select id="status" name="status" class="form-control select2" autocomplete="off">
                                <option value="free">Free</option>
                                <option value="occupied">Occupied</option>
                        </select>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>"> <?php echo e(__('rooms.create.cancel')); ?></a>
                        <button type="submit" class="btn btn-success"> <?php echo e(__('rooms.create.save')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/users/edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('assets/admin/js/users/edit.js')); ?>" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>