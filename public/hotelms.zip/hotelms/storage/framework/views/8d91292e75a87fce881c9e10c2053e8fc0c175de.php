<?php $__env->startSection('title', __('dashboard.title')); ?>

<?php $__env->startSection('content'); ?>
<!-- page content -->
<!-- top tiles -->
<div class="clearfix"></div>
<div class="row top_tiles">
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="tile-stats">
      <div class="icon"><i class="fa fa-address-card-o"></i></div>
      <div class="count"><?php echo e($count_occupants); ?></div>
      <h3>Guests</h3>
      <p><span><?php echo e($count_checking_out); ?></span> checking out today</p>
    </div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="tile-stats">
      <div class="icon"><i class="fa fa-building"></i></div>
      <div class="count"><?php echo e($count_reservations); ?></div>
      <h3>Reservations</h3>
      <p><span><?php echo e($count_checking_in); ?></span> checking in today</p>
    </div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="tile-stats">
      <div class="icon"><i class="fa fa-bed"></i></div>
      <div class="count"><?php echo e($count_free_rooms); ?></div>
      <h3>Free Rooms</h3>
      &nbsp;
    </div>
  </div>
  <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="tile-stats">
      <div class="icon"><i class="fa fa-address-book-o"></i></div>
      <div class="count"><?php echo e($count_customers); ?></div>
      <h3>Customers</h3>
      &nbsp;
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Guests</h2>

        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th><?php echo e(__('dashboard.table_header_room')); ?></th>
                <th> <?php echo e(__('dashboard.table_header_customer')); ?> </th>
                <th> <?php echo e(__('dashboard.table_header_date')); ?> </th>
                <th> <?php echo e(__('dashboard.table_header_duration')); ?> </th>

                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $occupants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($occupant->room->name); ?></td>
                <td><?php echo e(title_case($occupant->customer->firstname." ".$occupant->customer->lastname)); ?></td>

                <td><?php echo e($occupant->checkout_date); ?></td>
                <td><?php echo e($occupant->duration); ?> days</td>


                <td>
                    
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('checkout', $occupant)): ?>
                      <form style="display: inline;" action="<?php echo e(route('occupants.checkout', [$occupant->id])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-xs btn-primary" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('dashboard.checkout')); ?>">
                          <?php echo e(__('dashboard.checkout')); ?> 
                        </button>
                      </form>
                      <?php endif; ?> 
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div><!-- x-content -->
        </div><!-- x-panel -->
      </div><!-- col-md-12 -->
    </div><!-- row -->



    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Upcoming Reservations</h2>

            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th><?php echo e(__('dashboard.table_header_room')); ?></th>
                  <th> <?php echo e(__('dashboard.table_header_customer')); ?> </th>
                  <th> <?php echo e(__('dashboard.table_header_arrival')); ?> </th>
                  <th> <?php echo e(__('dashboard.table_header_duration')); ?> </th>

                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($reservation->room->name); ?></td>
                  <td><?php echo e(title_case($reservation->customer->firstname." ".$reservation->customer->lastname)); ?></td>

                  <td><?php echo e($reservation->arrival_date); ?></td>
                  <td><?php echo e($reservation->duration); ?> days</td>


                  <td>
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('reservations.show', [$reservation->id])); ?>" data-toggle="tooltip" data-placement="top" data-title="<?php echo e(__('dashboard.show')); ?>">
                      <?php echo e(__('dashboard.checkin')); ?> 
                    </a>
                          
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                </div><!-- x-content -->
              </div><!-- x-panel -->
            </div><!-- col-md-12 -->
          </div><!-- row -->





        </div>

        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>
        ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
        <script src="<?php echo e(asset('vendors/Chart.js/dist/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/jquery-sparkline/dist/jquery.sparkline.min.js')); ?>"></script>

        <script src="<?php echo e(asset('vendors/Flot/jquery.flot.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/Flot/jquery.flot.pie.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/Flot/jquery.flot.time.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/Flot/jquery.flot.stack.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/Flot/jquery.flot.resize.js')); ?>"></script>
        <script src="<?php echo e(asset('vendors/DateJS/build/date.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/admin/js/dashboard.js')); ?>"></script>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('styles'); ?>
        ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
        <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/dashboard.css')); ?>">
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>