<?php $__env->startSection('title', __('reservations.edit.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
             <form action="<?php echo e(route('reservations.update', [$reservation->id])); ?>" method="post" class='form-horizontal form-label-left'>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name" >
                        <?php echo e(__('reservations.edit.name')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <select id="customer" class="form-control <?php if($errors->has('customer')): ?> parsley-error <?php endif; ?>"
                               name="customer" required>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>" <?php echo e(($reservation->customer->id == $customer->id)?"selected":""); ?>><?php echo e(title_case($customer->firstname." ".$customer->lastname)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>
                </div>

                <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="room" >
                        <?php echo e(__('reservations.edit.room')); ?>

                        <span class="required">*</span>
                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <select id="name" class="form-control <?php if($errors->has('room')): ?> parsley-error <?php endif; ?>"
                               name="room" required>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($room->id); ?>" <?php echo e(($reservation->room->id == $room->id)?"selected":""); ?>><?php echo e($room->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>
                </div>
                
                
                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="date" >
                        <?php echo e(__('reservations.edit.date')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="name" type="text" class="form-control <?php if($errors->has('date')): ?> parsley-error <?php endif; ?>"
                               name="date" value="<?php echo e($reservation->arrival_date); ?>" required>
                        
                    </div>
                </div>


                 <div class="col-sm-6 col-xs-12 form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="duration" >
                        <?php echo e(__('reservations.edit.duration')); ?>

                    </label>
                    <div class="col-sm-9 col-xs-12">
                        <input id="name" type="text" class="form-control <?php if($errors->has('duration')): ?> parsley-error <?php endif; ?>"
                               name="duration" value="<?php echo e($reservation->duration); ?>" required>
                        
                    </div>
                </div>                

               
                

               

                <div class="col-sm-9 col-xs-12 form-group">
                    <label class="control-label col-md-2 col-sm-2 col-xs-12" for="notes">
                        <?php echo e(__('reservations.edit.notes')); ?>

                    </label>
                    <div class="col-sm-10 col-xs-12">
                        <textarea id="notes" class="form-control <?php if($errors->has('notes')): ?> parsley-error <?php endif; ?>"
                            name="notes"><?php echo e($reservation->notes); ?></textarea>
                    </div>
                </div>

                




                <div class="form-group">
                    <div class="col-sm-4 col-xs-12 col-sm-offset-4 pull-right">
                        <a class="btn btn-primary" href="<?php echo e(URL::previous()); ?>"> <?php echo e(__('reservations.edit.cancel')); ?></a>
                        <button type="submit" class="btn btn-success"> <?php echo e(__('reservations.edit.save')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/users/edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('assets/admin/js/users/edit.js')); ?>" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>